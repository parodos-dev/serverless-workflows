# Autojump plugin

This plugin loads the [autojump navigation tool](https://github.com/wting/autojump).

To use it, add `autojump` to the plugins array in your zshrc file:

```zsh
plugins=(... autojump)
```

More info on the usage: https://github.com/wting/autojump
