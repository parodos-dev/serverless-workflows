Config files
------------

This is my personal config for all my tools. 

Install 
-------

    git clone https://github.com/eloycoto/dotfiles
    ./install.sh 

Warning
-------

- This script change the vimrc config. 
- This script install zsh as default terminal. 
- All gitignore files are removed
