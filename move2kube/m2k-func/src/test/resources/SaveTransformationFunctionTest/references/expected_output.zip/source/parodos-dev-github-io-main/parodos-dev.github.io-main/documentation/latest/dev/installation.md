---
layout: documentation
title: Manual installation
---
